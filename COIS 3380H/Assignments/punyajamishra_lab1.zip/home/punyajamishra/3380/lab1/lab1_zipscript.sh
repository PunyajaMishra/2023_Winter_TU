#!/usr/bin/bash

# --------------------------------------------------------------
# Script that zips the folder/file specified in the argument
# 
# Name : lab1_zipscript.sh
# 
# Written By: Punyaja Mishra - 18 January 2023
# 
# Purpose : Zips files and folders for submissions
# 
# Description of parameters :
#   ZIPFOLDER - the name of the folder after being zipped. Includes username and lab name
#   argv[1] - directory to be zipped
#
# Libraries required :
#   None
# --------------------------------------------------------------


# Making sure filepath argument has been provided
if [ -z $1 ]; then
echo You forgot to supply filepath to the folder being zipped
exit 1
fi

# If provided directory name does not exist
if [ ! -d $1 ]; then
echo No such directory exists
exit 1
fi

# using env variable logname and argument  to specify zip folder's name
ZIPFOLDER=${LOGNAME}_$1.zip
echo creating the backup archive: ${ZIPFOLDER}
# zip command and making sure zip folder goes into HOME directory
zip -r $HOME/${ZIPFOLDER}  $HOME/3380/$1







