#!/usr/bin/bash

# ------------------------------------------------------------------------
# Analyze web logs
#
# Name : lab1_weblog_script.sh
#
# Written By : Punyaja Mishra - January 2023
#
# Purpose : Analysze web logs and find invalid web searches and their IP
#
# Description of parameters : 
#   None. Only bash commands

# -------------------------------------------------------------------------


# ----------Find all matches of the 404 - invlaid pages--------------
# all lines that have 404 - notice the blanks so that it only fetches the logs that got error 404 and does not have a 404 in their name or somewhere
grep -e " 404 " /home/COIS/3380/lab1/system_logs* |
# awk by using default space as a field seperator. Then fetching the 6th and 7th column which is the GET/POST and the page reference columns
awk '{print $6, $7}' |
# sort the result so all repititions are together
sort |
# count all repititions and get that number printed and then put it all into the file
uniq -c > /home/punyajamishra/3380/lab1/lab1_countedlogs.txt



# -----------put top 10 most accessed pages but invalid (404) in the file
# we have similar code as above
grep -e " 404 " /home/COIS/3380/lab1/system_logs* |
awk '{print $6, $7}' |
sort |
uniq -c |
# now we also sort the numericals in a reverse order to get the top 10 most accessed
sort -nr |
# get only top 10 and then output into a txt file
head -n 10 > /home/punyajamishra/3380/lab1/top_ten_404_pages.txt


# ----------Lab1 All IP Addresses txt file
# all lines that have 404 error
grep -e " 404 " /home/COIS/3380/lab1/system_logs* |
# get all IP addresses
grep -o '[0-9]\{1,3\}\.[0-9]\{1,3\}\.[0-9]\{1,3\}\.[0-9]\{1,3\}' |
# sort to get all repititions together
sort |
# count the repititions 
uniq -c |
# sort in reverse order and put it in a file
sort -nr > /home/punyajamishra/3380/lab1/lab1_all_IPs.txt


# ------------extract top 10 IP address that look for invalid page
# all lines that have 404 error
grep -e " 404 " /home/COIS/3380/lab1/system_logs* |
# get all IP addresses
grep -o '[0-9]\{1,3\}\.[0-9]\{1,3\}\.[0-9]\{1,3\}\.[0-9]\{1,3\}' |
# sort to get all repititions together
sort |
# count the repititions
uniq -c |
# sort in reverse order to get the descending order 
sort -nr |
# top 10 only and put in a file
head -n 10 > /home/punyajamishra/3380/lab1/top_10_IPs.txt


# -----------get top 2 IP address MANUALLY and find their geolocation
# TOP IP is : 192.75.12.69 - searching and saving it in the file names 192.75.12.69
wget -q http://ipinfo.io/192.75.12.69 

# 2nd IP is:129.211.4.119-searching and saving it in the file name 129.211.4.119
wget -q http://ipinfo.io/129.211.4.119


