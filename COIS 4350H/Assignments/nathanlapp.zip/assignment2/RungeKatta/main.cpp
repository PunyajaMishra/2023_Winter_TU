#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <omp.h>
double rk4(double(*f)(double, double), double dx, double x, double y)
{
	double k1 = dx * f(x, y);
	double k2 = dx * f(x + dx / 2, y + k1 / 2);
	double k3 = dx * f(x + dx / 2, y + k2 / 2);
	double k4 = dx * f(x + dx, y + k3);
	return y + (k1 + 2 * k2 + 2 * k3 + k4) / 6;
}

double rate(double x, double y)
{
	return x * sqrt(y);
}
double dydx(double x, double y)
{
    return((x - y)/2);
}
int main(void)
{
	double *y, *x, y2;
	double x0 = 0, x1 = 10, dx = .1;
	int i, n = 1 + (x1 - x0)/dx;
	y = (double *)	malloc(sizeof(double) * n);
	x = (double *) 	malloc(sizeof(double) * n);

	x[0] = x0;
	#pragma omp parallel for shared(x)
	for(i = 1 ; i < n;i++)
	{
		x[i] = x0 + dx * (i-1);
	}

    
	for (y[0] = 1, i = 1; i < n; i++)
	{
		y[i] = rk4(dydx, dx,x[i], y[i-1]);
	}
		

	printf("x\ty\trel. err.\n------------\n");
	for (i = 0; i < n; i += 10) {
		
		y2 = pow(x[i] * x[i] / 4 + 1, 2);
		printf("%g\t%g\t%g\n", x[i], y[i], y[i]/y2 - 1);
	}

	return 0;
}