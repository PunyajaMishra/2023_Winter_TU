#include "main.h"
#include <math.h>
#include <iostream>
#include <stdio.h>
#include <assert.h>
#include <iomanip>
#include <omp.h>
#include <string.h>
#include <algorithm>
#include "stb_image_write.h"

int main(int argc, char** argv)
{
    int worldSize = 10000;
    uint numChunks = 100;
    if(argc == 2)
    {
        worldSize = (int)std::atoi(argv[1]);
    }
    if(argc == 3)
    {
        numChunks = (uint)std::atoi(argv[2]);
    }

    World world = createWorld({.size = worldSize,.numChunks = numChunks});
    world.write(0,world.height/2,100000);
    runSimulation(world,__INT_MAX__);
    writeWorldData(world,"./images/world.png");
    //printWorld(world);
    
}


void runSimulation(World& world, int iterations)
{
    int iteration =0 ;
    int cellsRead = 0;
    int cellsUnderThreshold = 0;
    int sum;
    while(iteration <= iterations)
    {
        cellsRead = 0;
        cellsUnderThreshold = 0;
        sum = 0;
        #pragma omp parallel shared(cellsRead,cellsUnderThreshold,sum,world)
        {   
            #pragma omp single 
            updateChunk(world.root,world,&cellsRead,&cellsUnderThreshold,&sum);
        }
        #pragma omp taskwait
        
        
        
       
        
        double progress = cellsUnderThreshold/(double)(cellsRead);
        if(iteration % 100== 0)
        {
            double average = sum / (double)cellsRead;
            std::cout << iteration << " Progress: " << progress << " Average: " << average <<std::endl;

        if(iteration % IMAGE_WRITE_STEP == 0)
        {   
            const char* fileNameFmt = "./images/world%d.png";
            char * fileName = (char*) malloc(sizeof(char) * 100);
            
            sprintf(fileName,fileNameFmt,iteration);
            
            writeWorldData(world,fileName);
            free(fileName);
            //printWorld(world);
        }
        }
        iteration++;
        if(progress >= 1.0)
        {
            std::cout << iteration << " Done\n";
            iteration = iterations+1;
            break;
            
        }


    }
}

void updateChunk(ChunkNode* root,World& world,int* cellsRead,int* cellsUnderThreshold,int* sum)
{
    if(root == nullptr)
    {
        return;
    }
    ChunkNode* left = root->left;
    //Traverse chunks in-order.
    //So traverse all left children, then current, then all right children
    //Having the chunks be represented as a binary tree is useful for parallelization, traversals are just new tasks
    #pragma omp task firstprivate(root)
        updateChunk(root->left,world,cellsRead,cellsUnderThreshold,sum);
    
    Chunk* chunk = root->chunk;
    int i,j,k;

    double** sinkBuffer = new double*[chunk->height+2];
    
    
    #pragma omp parallel for
    for(i = 0; i < chunk->height+2;i++)
    {
        sinkBuffer[i] = new double[chunk->width+2];
        
        std::fill_n(sinkBuffer[i],chunk->width+2,0);
        
        
        
    }

    
    //Traverse bounds of current chunk
    #pragma omp parallel for shared(world,chunk) 
    for(i= chunk->originY;i < chunk->originY + chunk->height;i++)
    {
        #pragma omp parallel for shared(world,chunk) 
        for(j = chunk->originX; j < chunk->originX + chunk->width;j++)
        {
            double cellValue = world.read(j,i);
            #pragma omp critical
            {
                (*cellsRead)++;
                (*sum) += world.read(j,i);
                if(cellValue <= THRESHOLD)
                {
                    (*cellsUnderThreshold)++;
                }
            }
            
            double accumulation = 0.0;
            int neighbors =0;
            //Calculate sum of all neighbors
            // Having so much levels of identendation is *DIGUSTING* so instead of a 2 for loops to iterate through all neighbors, it loops through using 1D index offsets
           
            for(k = 0; k < 9;k++)
            {
                //Get offset x and y for neighbour. Need to be translated so it goes from -1 to 1. Instead of 0 to 2
                int offX = (k%3) - 1;
                int offY = (k/3) - 1;
                

                if(world.isInBounds(j + offX,i + offY) && !(offX ==0 && offY == 0) )
                {
                    accumulation += world.read(j + offX,i + offY);
                    neighbors++;
                    
                }
            }
            double lossAmount = 0.05 * (cellValue - (accumulation/neighbors));

            
            if(lossAmount > 0)
            {
                sinkBuffer[(i - chunk->originY) + 1][(j - chunk->originX) +1] -= lossAmount * neighbors;
                for(k = 0; k < 9;k++)
                {
                    //Get offset x and y for neighbour. Need to be translated so it goes from -1 to 1. Instead of 0 to 2
                    int offX = (k%3) - 1;
                    int offY = (k/3) - 1;

                    

                    if(world.isInBounds(j + offX,i + offY) && !(offX ==0 && offY == 0) )
                    {
                        double neighbourValue = world.read(j + offX, i + offY);
                        sinkBuffer[(i + offY - chunk->originY) +1][(j +offX - chunk->originX) + 1] += lossAmount;
                       
                    }
                }
            }
            else if(lossAmount < 0)
            {
               
                for(k = 0; k < 9;k++)
                {
                    //Get offset x and y for neighbour. Need to be translated so it goes from -1 to 1. Instead of 0 to 2
                    int offX = (k%3) - 1;
                    int offY = (k/3) - 1;

                    

                    if(world.isInBounds(j + offX,i + offY) && !(offX ==0 && offY == 0) )
                    {
                        double neighbourValue = world.read(j + offX,i + offY);
                        
                        if(neighbourValue > 0 && cellValue < neighbourValue)
                        {
                            
                            double heightFactor = 1.0 - (  cellValue/ neighbourValue);
                            heightFactor *= 0.1;
                            sinkBuffer[(i - chunk->originY) + 1][(j - chunk->originX) +1] += neighbourValue * (heightFactor);
                            sinkBuffer[(i + offY - chunk->originY) +1][(j +offX - chunk->originX) + 1] -=neighbourValue * (heightFactor);
                            
                        }
                        
                        
                    }
                }
            }
           
            
        }
    }
    
    #pragma omp parallel for
    for(i= chunk->originY - 1;i < chunk->originY + chunk->height + 1;i++)
    {
        #pragma omp parallel for
        for(j = chunk->originX - 1; j < chunk->originX + chunk->width + 1;j++)
        {
            if(world.isInBounds(j,i))
            {
                double delta = sinkBuffer[i - (chunk->originY - 1)][j - (chunk->originX - 1)];
                if(delta != 0.0)
                {
                    
                    world.write(j,i,world.read(j,i) + delta);
                    
                }

                
            }

            
        }
    }
    
    //chunk->flush();


    
    for(i = 0; i < chunk->height+2;i++)
    {
        delete[] sinkBuffer[i];
        
        
    }
   
    delete[] sinkBuffer;
    //Traverse right children
    #pragma omp task firstprivate(root)
        updateChunk(root->right,world,cellsRead,cellsUnderThreshold,sum);
}

World createWorld(CreateWorldDesc desc)
{
    World world;
    int i,j,k;
    world.height = world.width = sqrt(desc.size);
    world.chunksX = world.chunksY = sqrt(desc.numChunks);
    int chunkWidth = world.width / world.chunksX;
    int chunkHeight = world.height / world.chunksY;

    world.chunks = new Chunk*[world.chunksY];
    for(i = 0; i < world.chunksY;i++)
    {
        world.chunks[i] = new Chunk[world.chunksX];
        for(j = 0; j < world.chunksX;j++)
        {

            Chunk chunk = createChunk({.width = chunkWidth,.height = chunkHeight,.worldX = j * chunkWidth,.worldY = i * chunkHeight});
            world.chunks[i][j] = chunk;
            

        }
    }
    world.root = nullptr;
    return world;

}

Chunk createChunk(CreateChunkDesc desc)
{
    int i,j;
    Chunk chunk;
    chunk.originX = desc.worldX;
    chunk.originY = desc.worldY;
    chunk.height = desc.height;
    chunk.width = desc.width;

    chunk.values = new double*[chunk.height];
    chunk.activated = false;
    for(i = 0; i < chunk.height;i++)
    {
        chunk.values[i] = new double[chunk.width];
        //Init chunks to 0
        std::fill_n(chunk.values[i],chunk.width,0);
    }
    return chunk;
}

double& World::read(int x, int y) const
{
    /*Chunk* chunk = findChunk(x,y);
    
    if(chunk == nullptr)
    {
        
        #pragma omp parallel for
        for(int i = 0; i < this->chunksY;i++)
        {
            
            for(int j = 0; j < this->chunksX;j++)
            {
                if(this->chunks[j][i].containsPoint(x,y))
                {
                    chunk = &this->chunks[j][i];
                    //break;
                }
            }
        }
    }

    if(chunk == nullptr)
    {
        std::cout << "Could not find point " << x << " " << y;
    }*/
    
    int chunkWidth = this->width/this->chunksX;
    int chunkHeight = this->height/this->chunksY;
    int ix = (int)floor(x/chunkWidth);
    int iy = (int)floor(y/chunkHeight);
    Chunk* chunk = &(this->chunks[iy][ix]);
    int cx = x - chunk->originX;
    int cy = y - chunk->originY;
    return chunk->values[cy][cx];

}



void World::write(int x, int y, double value)
{
    
    /*Chunk* chunk = findChunk(x,y);

    if(chunk == nullptr)
    {
        #pragma omp parallel for
        for(int i = 0; i < this->chunksY;i++)
        {
            
            for(int j = 0; j < this->chunksX;j++)
            {
                if(this->chunks[j][i].containsPoint(x,y))
                {
                    chunk = &this->chunks[j][i];
                    //break;
                }
            }
        }
    }*/
    
    int chunkWidth = this->width/this->chunksX;
    int chunkHeight = this->height/this->chunksY;
    int ix = (int)floor(x/chunkWidth);
    int iy = (int)floor(y/chunkHeight);
    Chunk* chunk = &(this->chunks[iy][ix]);

    int cx = x - chunk->originX;
    int cy = y - chunk->originY;
    chunk->values[cy][cx] = value;
    
    if(!chunk->activated)
    {
        activateChunk(*this,chunk);
    }
}


bool Chunk::containsPoint(int x, int y)
{
    return (x >= this->originX  && x < this->originX + this->width) && (y >= this->originY  && y < this->originY+ this->height);
}

bool World::isInBounds(int x, int y)
{
    return x >= 0 && x < this->width && y >= 0 && y < this->height;
}


Chunk* World::findChunk(int x, int y) const
{

    ChunkNode* current = this->root;
    Chunk* chunk = nullptr;
    while(current != nullptr)
    {
        int value = y * this->width + x;
        
        if(!current->chunk->containsPoint(x,y))
        {
            
            if(value > current->value)
            {
                current = current->right;
            }
            else
            {
                current = current->left;
            }
        }
        else
        {
            chunk = current->chunk;
            current = nullptr;
        }
    }
    
    return chunk;
}

void printWorld(const World& world)
{
    std::cout << std::setprecision(2) << std::fixed;
    for(int i = 0; i < world.height;i++)
    {
        for(int j = 0; j < world.width;j++)
        {
               std::cout << "\t" << world.read(j,i) << " ";
        }
        std::cout << std::endl;
    }
    std::cout << std::endl;
}

void activateChunk(World& world, Chunk* chunk)
{
    ChunkNode* node = new ChunkNode;
    node->value = chunk->originY * world.height + chunk->originX;
    node->chunk = chunk;
    node->left = nullptr;
    node->right = nullptr;
    chunk->activated = true;
    //std::cout << "Activated chunk " << node->value << std::endl; 
    if(world.root == nullptr)
    {
        world.root = node;
        return;

    }
    ChunkNode* root = world.root;
    //Start new parallel task thread for inserting chunks
    #pragma omp parallel
    {
        #pragma omp single 
            insertChunk(root,node);  
    }
    #pragma omp taskwait 
    
}

void insertChunk(ChunkNode* root, ChunkNode* node)
{
    ChunkNode* newRoot;

    //Look for place in binary tree for chunk to be inserted

    if(node->value > root->value)
    {
        if(root->right == nullptr)
        {
            
            root->right = node;
            
            return;
        }
        ChunkNode* right = root->right;
        #pragma omp task firstprivate(node,root)
            insertChunk(right,node);
    }
    else
    {
        if(root->left == nullptr)
        {
            root->left = node;
            
            return;
        }
        ChunkNode* left = root->left;
        #pragma omp task firstprivate(node,root)
            insertChunk(left,node);
    }

}

void writeWorldData(const World& world, const char* path)
{
    #ifdef STB_IMAGE_WRITE_IMPLEMENTATION
    int i,j;
    //Array to hold image data.
    //Obviously needs to be at least width * height long but also needs to hold enough room for all channels.
    uint8_t* imageData = new uint8_t[(world.width * world.height) * 3];
    #pragma omp parallel for
    for(i = 0 ; i < world.height;i++)
    {
        #pragma omp parallel for
        for(j = 0; j < world.width;j++)
        {
            int c;
            //Normalize to THRESHOLD, could also be normalized to the maximum cell value for greater accuracy.
            float val = world.read(j,i) / THRESHOLD;
            for(c = 0; c < 3; c++)
            {
                #pragma omp task
                imageData[((i * world.width) + j) * 3 + c] = val * 255.0f;
            }
        }
    }
    #pragma omp taskwait
    stbi_write_png(path,world.width,world.height,3,imageData, world.width * 3);
    delete[] imageData;
    #endif
}