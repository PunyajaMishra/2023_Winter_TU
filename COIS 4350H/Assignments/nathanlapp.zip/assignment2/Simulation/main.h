#ifndef MAIN_H
#define MAIN_H

#include <cstdlib>

#define MAX(a,b) (a > b ? a : b)

#define THRESHOLD 12.0
#define FAST_MOD(a,b) (a & (b - 1))

#define IMAGE_WRITE_STEP 1

struct Chunk
{
    int originX;
    int originY;
    int width;
    int height;
    double** values;    
    bool activated;
    bool containsPoint(int x, int y);
};

struct ChunkNode
{
    Chunk* chunk;
    ChunkNode* left;
    ChunkNode* right;
    int value;
};

struct World
{
    
    int width;
    int height;
    Chunk** chunks;
    int chunksX;
    int chunksY;
    ChunkNode* root;
    

    double& read(int x, int y) const;
    void write(int x, int y, double value);
    bool isInBounds(int x, int y);
    Chunk* findChunk(int x, int y) const;

};

typedef struct CreateWorldDesc
{
    int size;
    uint numChunks;

} CreateWorldDesc;
typedef struct CreateChunkDesc
{
    int width;
    int height;

    int worldX;
    int worldY;
} CreateChunkDesc;

World createWorld(CreateWorldDesc desc);
Chunk createChunk(CreateChunkDesc desc);
void printWorld(const World& world);
void activateChunk(World& world, Chunk* chunk);
void insertChunk(ChunkNode* root, ChunkNode* node);
void updateChunk(ChunkNode* root,World& world,int* cellsRead, int* cellsUnderThreshold,int* sum);
void runSimulation(World& world, int iterations);
bool pointLiesInChunk(const Chunk& chunk, int x, int y);
Chunk* chunkSearch(ChunkNode* root,int value);
void writeWorldData(const World& world, const char* name);


#endif